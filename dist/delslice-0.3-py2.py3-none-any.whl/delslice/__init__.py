"""Top-level package for delslice."""

__author__ = """Neil Baldwin"""
__email__ = 'info@marmotaudio.co.uk'
__version__ = '0.3'
